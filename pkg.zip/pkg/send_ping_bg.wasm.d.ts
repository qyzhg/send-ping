/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function start_ping_task(a: number, b: number, c: number, d: number): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function wasm_bindgen__convert__closures__invoke1_mut__h481c02721370c5b5(a: number, b: number, c: number): void;
export function _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hd199aed53e876e08(a: number, b: number): void;
export function wasm_bindgen__convert__closures__invoke1_mut__h0cb701d578180367(a: number, b: number, c: number): void;
export function __wbindgen_exn_store(a: number): void;
